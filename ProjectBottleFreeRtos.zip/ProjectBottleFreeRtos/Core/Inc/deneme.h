#ifndef __DENEME_H
#define __DENEME_H

#include <stdint.h>

#define RX_BUFFER_SIZE 64

#define configUSE_TIMERS                         1

#define configTIMER_TASK_PRIORITY                ( configMAX_PRIORITIES - 1 )

#define configTIMER_TASK_STACK_DEPTH             ( (uint16_t)configMINIMAL_STACK_SIZE * 2 )

#define configTIMER_QUEUE_LENGTH                 10



typedef struct {
    int dx;
    int dy;
} Coordinates;

extern volatile Coordinates sharedCoordinates;

void ControlTask(void *argument);
void DistanceTask(void *argument);
void LoggerTask(void *argument);

void ServoFollow6(void);
void ServoFollow3(void);
void ServoFollow5(void);
void GripControl(void);

void UpdateCoordinatesFromLine(const char* line);
int parseCoordinates(const char* data, Coordinates* coord);

#endif /* __DENEME_H */
