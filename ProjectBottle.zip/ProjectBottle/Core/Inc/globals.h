#ifndef GLOBALS_H
#define GLOBALS_H

#define RX_BUFFER_SIZE 64

extern uint8_t uart2_rx_buffer[RX_BUFFER_SIZE];

#endif
