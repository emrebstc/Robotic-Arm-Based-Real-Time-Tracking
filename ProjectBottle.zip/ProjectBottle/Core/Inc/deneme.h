#ifndef INC_DENEME_H_
#define INC_DENEME_H_

#include "main.h"
#include <stdint.h>

#define RX_BUFFER_SIZE 64

extern UART_HandleTypeDef huart2;
extern UART_HandleTypeDef huart3;
extern TIM_HandleTypeDef htim2;

extern uint8_t rx_buffer_it;

extern uint8_t uartLineBuffer[RX_BUFFER_SIZE];
extern uint8_t uartLineIndex;
extern uint32_t Distance;

typedef struct {
    int dx;
    int dy;
} Coordinates;

extern volatile Coordinates sharedCoordinates;

int parseCoordinates(const char* data, Coordinates* coord);
void UpdateCoordinatesFromLine(const char* line);

void ServoFollow6(void);
void ServoFollow3(void);
void LoggerTask(void);
void UltrasonicTask(void);

#endif /* INC_DENEME_H_ */
